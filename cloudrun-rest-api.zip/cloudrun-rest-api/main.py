import os
from flask import Flask
from typing import Any
import requests
from flask import request, make_response, Flask, jsonify, send_file
import json
import google.auth
from google.auth.transport.requests import AuthorizedSession
from google.oauth2 import service_account


app = Flask(__name__)

print('Composer_rest_api')


def make_composer_request(sa_secret_key: str, url: str, method: str = "GET",
                                      **kwargs: Any) -> google.auth.transport.Response:
    print('in params:', sa_secret_key)
    service_account_json = os.environ.get(sa_secret_key)
    print('received secret')

    # load Service Account JSON into a dictionary
    gcp_json_credentials_dict = json.loads(service_account_json)

    # build credentials including scope
    credentials = service_account.Credentials.from_service_account_info(
        gcp_json_credentials_dict,
        scopes=['https://www.googleapis.com/auth/cloud-platform'])
    
    authed_session = AuthorizedSession(credentials)
    print(authed_session)
    # Set the default timeout, if missing
    if "timeout" not in kwargs:
       kwargs["timeout"] = 90

    return authed_session.request(method, url, **kwargs)


@app.route('/ping', methods=['GET'])
def ping():
    return jsonify({"status": "Alive"
                    }), 200


@app.route("/trigger_dag", methods=['POST'])
def trigger_dag():
    data = json.loads(request.data)
    end_point = data['dag_id']
    website_url = data['url']
    sa_secret_key = data['sa_secret_key']
    print('sa_secret_key:', sa_secret_key)
    body_json = data['dag_config']
    print(body_json)
    request_url = f"{website_url}/api/v1/dags/{end_point}/dagRuns"
    json_data = {"conf": body_json}
    print(json_data)
    headers = {'Content-type': 'application/json', 'Accept': 'application/x-www-form-urlencoded'}

    response = make_composer_request(
        sa_secret_key, request_url, method="POST", json=json_data, headers=headers
    )
    print(response)
    print(response.text)

    if response.status_code == 403:
        raise requests.HTTPError(
            "You do not have a permission to perform this operation. "
            "Check Airflow RBAC roles for your account."
            f"{response.headers} / {response.text}"
        )
    elif response.status_code != 200:
        response.raise_for_status()
    else:
        return response.text


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", "8080")))